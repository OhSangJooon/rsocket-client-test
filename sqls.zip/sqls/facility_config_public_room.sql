INSERT INTO main_11.facility_config_public_room (facility_id, is_available_enter_for_private_ticket, shard_seq, created_date_time, updated_date_time) VALUES (14, 1, 11, 1747716249844, null);
INSERT INTO main_11.facility_config_public_room (facility_id, is_available_enter_for_private_ticket, shard_seq, created_date_time, updated_date_time) VALUES (19, 1, 11, 1748225279515, null);
INSERT INTO main_11.facility_config_public_room (facility_id, is_available_enter_for_private_ticket, shard_seq, created_date_time, updated_date_time) VALUES (30, 1, 11, 1746601731512, null);
INSERT INTO main_11.facility_config_public_room (facility_id, is_available_enter_for_private_ticket, shard_seq, created_date_time, updated_date_time) VALUES (56, 1, 11, 1749092960631, null);
