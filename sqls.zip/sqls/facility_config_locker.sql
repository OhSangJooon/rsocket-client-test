INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (5, 0, 11, 1742985821867, 1747793592016);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (18, 1, 11, 1743557643406, null);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (26, 1, 11, 1745914508027, null);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (57, 1, 11, 1749438346541, null);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (85, 1, 11, 1750150858692, null);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (96, 1, 11, 1750386294688, null);
INSERT INTO main_11.facility_config_locker (facility_id, is_auto_return, shard_seq, created_date_time, updated_date_time) VALUES (98, 0, 11, 1750401917542, null);
