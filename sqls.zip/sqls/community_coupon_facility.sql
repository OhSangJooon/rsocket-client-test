INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1736129790438, 1747362980107, 5);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1744195050124, null, 3);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1744195050131, null, 4);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1744195050138, null, 2);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1744195086838, null, 31);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1744195089759, null, 1);
INSERT INTO main_11.community_coupon_facility (community_coupon_id, shard_seq, created_date_time, updated_date_time, facility_type_id) VALUES (28, 11, 1750135787527, null, 7);
