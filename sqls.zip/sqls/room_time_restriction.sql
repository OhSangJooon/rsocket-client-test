INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (10, 74, 1, 11, 1747637651294, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (10, 73, 1, 11, 1747637651607, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (10, 72, 1, 11, 1747637652024, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (10, 71, 1, 11, 1747637652606, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (53, 1118, 1, 11, 1750838154969, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (53, 1117, 1, 11, 1750838155440, null);
INSERT INTO main_11.room_time_restriction (facility_id, facility_timetable_id, restriction_type, shard_seq, created_date_time, updated_date_time) VALUES (53, 1116, 1, 11, 1750838155945, null);
